library(XLConnect)

loan <- readWorksheetFromFile("C:/Users/Mayur/Documents/Advance Data Science/Assignments_SDas/Assignment7/loan.xlsx", sheet = 1)
str(loan)

apply(loan,2,function(x) sum(is.na(x)))

#install.packages("neuralnet")
library(neuralnet)

library(nnet)
#  convert all the qualitative variables (factors) to 
#  binary ("dummy") variables, with the model.matrix function 
#  for NN model
fb <- paste(n, collapse = " + ")
fb <- as.formula(paste(" ~", fb))

m <- model.matrix( 
  fb, 
  data = loan 
)
n <- colnames(m)
n <- n[2:length(n)] # removing Intercept column
m <- m[,n]

#splitting the scaled data
index <- sample(1:nrow(m),round(0.80*nrow(m)))
train_ <- m[index,]
test_ <- m[-index,]


nTrain <- colnames(train_)
f <- as.formula(paste("Decisionreject ~", paste(nTrain[!nTrain %in% "Decisionreject"], collapse = " + ")))
f




nn <- neuralnet(f,data=train_,hidden=c(5,3), act.fct = "logistic",linear.output=T)

plot(nn)

cnt <- length(colnames(test_))
#predicting output
pr.nn <- compute(nn,test_[,1:cnt-1])
names(pr.nn['neurons'])

typeof(pr.nn$net.result)
x <- as.numeric(unlist(pr.nn$net.result))
y <- cut(x,breaks = 2, labels = c(0, 1))
cbind(test_$Decisionreject,y)
nnet

abline(0,1,lwd=2)
legend('bottomright',legend=c('NN','LM'),pch=18,col=c('red','blue'))

test_$Decisionreject - 


xy <- as.factor(pr.nn)