rm(list =ls(all=TRUE))

xls <- c(5,1,1,2,3,3,5,1,3,5,4,5,5,5,6)
x2s <- c(3,5,1,2,5,2,1,1,2,5,8,3,4,5,4,1)

ys <- c(rep(+1, 6), rep(-1,6))

my.data <- data.frame(x1=xls, x2=x2s, type=as.factor(ys))

my.data

install.packages('e1071')

library('e1071')

svm.model <- svm(type ~ ., data=my.data, type='C-Classification', kernel='linear', scale=FALSE, cost=1)

svm.model


svm.model <- svm(type ~ ., data=my.data, type='C-Classification', kernel='linear', scale=FALSE, cost=1)

svm.model


plot(my.data[,-3], col=(ys+3)/2, pch=19, xlim=c(-1,6), ylim = c(-1,6))
points(my.data(svm.model$index))