
# Install and Activate Packages
install.packages("twitteR", "RCurl", "RJSONIO", "stringr")
library(twitteR)
library(RCurl)
library(RJSONIO)
library(stringr)

# Declare Twitter API Credentials
api_key <- "wD9XB3nCUR7EKQmT9qyQRASn2" # From dev.twitter.com
api_secret <- "9sNLGekY6G6QuubDoU8wBIHhw36HIZjfGo3a1wBmRA21J7NgXl" # From dev.twitter.com
token <- "864455585286299648-SnWXOgAa775L2WluyIuSI5ysCA5uOom" # From dev.twitter.com
token_secret <- "NdQfLtSHBWmN6suu9l16yW4FYZymSJRZG4T5lRtWCZSaS" # From dev.twitter.com

# Create Twitter Connection
setup_twitter_oauth(api_key, api_secret, token, token_secret)

# Run Twitter Search. Format is searchTwitter("Search Terms", n=100, lang="en", geocode="lat,lng", also accepts since and until).

tweets <- searchTwitter("Bitcoin", n=5000, lang="en", since="2014-08-20")

# Transform tweets list into a data frame
tweets.df <- twListToDF(tweets)
length(tweets.df$text)

# Use the searchTwitter function to only get tweets within 50 miles of Los Angeles
#tweets_geolocated <- searchTwitter("Obamacare OR ACA OR 'Affordable Care Act' OR #ACA", n=5000, lang="en", geocode='34.04993,-118.24084,50mi', since="2014-08-20")
#tweets_geoolocated.df <- twListToDF(tweets_geolocated)

tweets.text <- tweets.df$text


library(NLP)
library(Rstem)
library(SnowballC)
library(ROAuth)
require(RCurl)
library(stringr)
library(tm)
library(ggmap)
library(dplyr)
library(plyr)
library(wordcloud)
library(glmnet)
library(e1071)

# Create corpus
corpus=Corpus(VectorSource(tweets.text))


# Convert to lower-case
corpus=tm_map(corpus,tolower)

# Remove stopwords
corpus=tm_map(corpus,function(x) removeWords(x,stopwords()))

# convert corpus to Plain Text
corpus=tm_map(corpus,PlainTextDocument)

corpus <- gsub('[[:punct:]]', '', corpus)
corpus <- gsub('[[:cntrl:]]', '', corpus)
corpus <- gsub('\\d+', '', corpus)
col=brewer.pal(6,"Dark2")
wordcloud(corpus, min.freq=25, scale=c(5,2),rot.per = 0.25,
          random.color=T, max.word=45, random.order=F,colors=col)


positives <- readLines("C:/Users/Mayur/Documents/Advance Data Science/Assignments_SDas/Assignment_8/positivewords.txt")
negatives <- readLines("C:/Users/Mayur/Documents/Advance Data Science/Assignments_SDas/Assignment_8/negativewords.txt")

dataFile <- tweets.text


sentimentScore <- function(dataFile, negatives, positives){
  final_scores <- matrix('', 0, 3)
  scores <- laply(dataFile, function(dataFile, negatives, positives){
    initial_dataFile <- dataFile
    
    #data cleaning and remove punctuation 
    dataFile <- gsub('[[:punct:]]', '', dataFile)
    dataFile <- gsub('[[:cntrl:]]', '', dataFile)
    dataFile <- gsub('\\d+', '', dataFile)
    dataFile <- tolower(dataFile)
    wordList <- str_split(dataFile, '\\s+')
    words <- unlist(wordList)
    
    #build vector containing matches
    positive_matches <- match(words, positives)
    negative_matches <- match(words, negatives)
    
    #sum up number of words
    positive_matches <- sum(!is.na(positive_matches))
    negative_matches <- sum(!is.na(negative_matches))
    
    score <- c(negative_matches, positive_matches)
    
    newrow <- c(initial_dataFile, score)
    final_scores <- rbind(final_scores, newrow)
    return(final_scores)
  }, negatives, positives)
  return(scores)
}
#sentimentScore

#build tables with score
result <- as.data.frame(sentimentScore(dataFile, negatives, positives))
#result <- cbind(result, 'result')
colnames(result) <- c('Review', 'Negatives', 'Positives')

result
summary(result)
dim(result)